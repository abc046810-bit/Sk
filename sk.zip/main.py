from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, filters, ContextTypes, CommandHandler
# 🔧 यहाँ अपना बॉट टोकन और ओनर ID डालें
BOT_TOKEN = "8398448002:AAHdAy_PwFUQ_Xnqb0MS9pFT4khugmHSD5M"
OWNER_ID = 6446087354  # @userinfobot से पता करें
# 🔹 यूज़र और उनके मैसेज ट्रैक करने के लिए
user_map = {}
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("नमस्ते 👋! आप कोई भी मैसेज भेजें, मैं ओनर तक पहुँचा दूँगा।")
async def forward_to_owner(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    user_id = user.id
    username = f"@{user.username}" if user.username else "कोई यूज़रनेम नहीं"
    text = update.message.text or "(कोई टेक्स्ट नहीं)"
    # हर यूज़र को एक unique message_id से जोड़ें
    user_map[update.message.message_id] = user_id
    msg = (
        f"📩 नया मैसेज:\n\n"
        f"👤 नाम: {user.first_name}\n"
        f"🆔 User ID: {user_id}\n"
        f"🔗 Username: {username}\n\n"
        f"💬 Message:\n{text}"
    )
    # ओनर को मैसेज भेजो (फॉरवर्ड जैसा)
    sent = await context.bot.send_message(chat_id=OWNER_ID, text=msg, parse_mode="HTML")
    # ताकि रिप्लाई करते वक्त पहचान सकें
    user_map[sent.message_id] = user_id
async def handle_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """अगर Owner किसी फॉरवर्ड मैसेज को reply करता है, तो बॉट यूज़र को वही भेज देता है"""
    if update.message.reply_to_message and update.effective_user.id == OWNER_ID:
        reply_to = update.message.reply_to_message.message_id
        if reply_to in user_map:
            target_user = user_map[reply_to]
            text = update.message.text
            await context.bot.send_message(chat_id=target_user, text=f"💌 Owner का जवाब:\n{text}")
            await update.message.reply_text("✅ जवाब भेज दिया गया।")
        else:
            await update.message.reply_text("⚠️ इस रिप्लाई का यूज़र नहीं मिला।")
    elif update.effective_user.id != OWNER_ID:
        await forward_to_owner(update, context)
app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.ALL, handle_reply))
print("🤖 Auto Reply बॉट चालू है... Ctrl+C से बंद करें।")
app.run_polling()